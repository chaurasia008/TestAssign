package StepDefinition_Login;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="src\\  main\\resources\\FeatureStepDef\\LoginPortal.feature",
		glue= {"StepDefinition_Login", "LoginFeature_StepDef.java"}, 
		format= {"pretty", "html:target/cucumber"}
		)
public class LoginRunner{

}
