package StepDefinition_Login;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.java.en.Given;



public class LoginFeature_StepDef {

	WebDriver driver;
	
	@Given("^I open my application$")
	public void i_open_my_application() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebDriver driver;
		
		        System.setProperty("webdriver.chrome.driver", "/compile/Jars/chromedriver.exe");
	    	    driver = new ChromeDriver();
	    	    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	    	    driver.manage().window().maximize();
	    	   
		//opening URL
	    	    driver.get("https://opensource-demo.orangehrmlive.com");
	    	    
	    
	}

	@Given("^I login with following credentials$")
	public void i_login_with_following_credentials() throws Throwable {
		
		//enter a valid login user name
	    driver.findElement(By.id("txtUsername")).sendKeys("Admin");

	    //enter a valid login password
		driver.findElement(By.id("txtPassword")).sendKeys("admin123");
		
		//click on login button
		driver.findElement(By.id("btnLogin")).click();
	  
	}

	@Given("^Validate landing Page$")
	public void validate_landing_Page() throws Throwable {
	   
	   // throw new PendingException();
	}
	
	
}

