package final_Assignment_Java_Q;

import java.util.ArrayList;
import java.util.List;

class Assignmentq4 {

	// method definition
        public static List<String> myMethod(){
	      
	       List<String> listStrings = new ArrayList<String>();
	       listStrings.add("Santosh");
	       listStrings.add("Areef");
	       listStrings.add("Atul");
	       listStrings.add("Jyoti");
	       
	       return listStrings;
	    		       
	   }

	   public static List<String> myMethod1(){
	       
		   List<String> listStrings1 = new ArrayList<String>();
	       listStrings1.add("Rashmee");
	       listStrings1.add("Saxena");
	       listStrings1.add("Uma");
	       listStrings1.add("Mounika");
	       
	       return listStrings1;
		  			   
	   }			   
}

public class ListCall {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		ArrayList<String> str= (ArrayList<String>) Assignmentq4.myMethod();
		
		ArrayList<String> str1= (ArrayList<String>) Assignmentq4.myMethod1();
		
		System.out.print("String list:" +str);
		
		System.out.print("\n\nString list:" +str1);

	}

}
