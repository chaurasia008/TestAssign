package final_Assignment_Java_Q;

class Company {
	 
	protected void address() {
		String str = "UHG,Sector-39,GGN";
		
		System.out.println("This is My office Address:"+str);
	}
}
 
class Home extends Company {
 
	public void address() {
		String str1 = "Sector39, GGN";
		super.address(); // invokes the super class method
		
		
		System.out.println("This is my Home Address..." +str1);
	}
}


public class AddressObjOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Company str = new Company(); // Company reference and object
		Company str1 = new Home(); // Company reference but Home object
 
		str.address();// runs the method in Company class
		str1.address();// Runs the method in eBay class
		
		

	}

}
