package final_Assignment_Java_Q;

import java.util.Properties;
import java.util.Set;

public class PrintPropertyFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Properties props = new Properties();
	    props.setProperty("Name", "Tom");
	    props.setProperty("Mobile", "1234567");
	    props.setProperty("Address", "Westley street");
	    

	 // Iterating properties using For

	    Set<String> keys = props.stringPropertyNames();
	    for (String key : keys) {
	      System.out.println(key + " : " + props.getProperty(key));
	    }

	}

}
